import torch
import torch.nn as nn
from dgllife.model.gnn.gcn import GCN
from dgllife.model.gnn.graphsage import GraphSAGE
from dgl.nn.pytorch import JumpingKnowledge
from dgllife.model.readout.weighted_sum_and_max import WeightedSumAndMax

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
class DGL_GCN_SAGE_JK(nn.Module):
    def __init__(self, in_feats, hidden_feats=None, activation=None, predictor_dim=None):
        super(DGL_GCN_SAGE_JK, self).__init__()
        self.gnn = GCN(in_feats=in_feats,                       hidden_feats=hidden_feats,                        activation=activation)
        self.sageGnn = GraphSAGE(in_feats=in_feats,  hidden_feats=hidden_feats,  activation=activation)

        gnn_out_feats = self.gnn.hidden_feats[-1]

        self.jk_lstm = JumpingKnowledge(mode='lstm', in_feats=gnn_out_feats, num_layers=2)
        self.jk_max = JumpingKnowledge(mode='max')
        self.readout = WeightedSumAndMax(gnn_out_feats)
        self.in_trans_sage = nn.Linear(in_feats, in_feats)
        self.transform = nn.Linear(gnn_out_feats * 2, predictor_dim)

    def forward(self, bg):

        bg = bg.to(device)
        feats = bg.ndata.pop('h')
        feats = self.in_trans_sage(feats)
        node_feats_sage = self.sageGnn(bg, feats)
        node_feats_gcn = self.gnn(bg, feats)
        node_feats = self.jk_lstm([node_feats_gcn , node_feats_sage]) #original is addition
        ###########Below is ablation study setup
        #node_feats = self.jk_lstm([node_feats_gcn + node_feats_sage])
        graph_feats = self.readout(bg, node_feats)
        return self.transform(graph_feats)
