import torch
from torch.autograd import Variable
import torch.nn.functional as F
from torch.utils import data
from torch.utils.data import SequentialSampler
from torch import nn

from tqdm import tqdm
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from time import time
from sklearn.metrics import mean_squared_error, roc_auc_score, average_precision_score, f1_score, log_loss
from lifelines.utils import concordance_index
from scipy.stats import pearsonr
import pickle
torch.manual_seed(2)
np.random.seed(3)
import copy
from prettytable import PrettyTable

import os

from DeepPurpose.utils import *
from DeepPurpose.model_helper import Encoder_MultipleLayers, Embeddings

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class MING(nn.Module):
    """Unified MPNN-MixHop architecture for drug-target interaction prediction"""
    def __init__(self,
                 # MPNN parameters
                 mpnn_hidden_size,
                 mpnn_depth,
                 # MixHop parameters
                 feature_number,
                 mixhop_layers=[32, 32, 32, 32],
                 # Fusion parameters
                 alpha=0.9,
                 device=torch.device('cuda')):
        super().__init__()
        self.device = device

        # Drug encoder (MPNN-based)
        self.hdn_model = MPNNWrapper(mpnn_hidden_size, mpnn_depth)

        # Target encoder (MixHop-based)
        self.hoagcn_model = MixHopNetwork(
            feature_number=feature_number,
            layers_1=mixhop_layers,
            layers_2=mixhop_layers,
            device=device
        )

        # Adaptive fusion parameter
        self.alpha = nn.Parameter(torch.tensor(alpha))

        # Unified predictor
        self.predictor = nn.Sequential(
            nn.Linear(mpnn_hidden_size + 1, 128),  # Combine both encodings
            nn.ELU(),
            nn.Linear(128, 1)
        )

    def forward(self, drug_feature, graph_data):
        """
        Unified forward pass
        :param drug_feature: MPNN input tuple (fatoms, fbonds, agraph, bgraph, N_atoms_bond)
        :param graph_data: Tuple (adj_matrix, features, idx_pairs)
        """
        # Drug encoding
        drug_emb = self.hdn_model(drug_feature)

        # Target encoding
        adj_matrix, features, idx = graph_data
        target_pred, _ = self.hoagcn_model(adj_matrix, features, idx)

        # Concatenate encodings
        combined = torch.cat([
            drug_emb,
            target_pred.detach()  # Prevent target gradients affecting drug encoder
        ], dim=1)

        # Adaptive fusion
        output = self.predictor(self.alpha * combined + (1 - self.alpha) * target_pred)
        return torch.sigmoid(output)

# Modified MixHopNetwork with dimension compatibility
class MixHopNetwork(nn.Module):
    def __init__(self, feature_number, layers_1, layers_2, device):
        super().__init__()
        self.abstract_feature = sum(layers_1) + sum(layers_2)
        self.bilinear = nn.Bilinear(self.abstract_feature, self.abstract_feature, 1)
        self.decoder = nn.Sequential(
            nn.Linear(1, 32),
            nn.ELU(),
            nn.Linear(32, 1)
        )

    def forward(self, adj_matrix, features, idx):
        # Original MixHop logic here
        latent = features  # Simplified for demonstration
        pred = self.bilinear(latent[idx[0]], latent[idx[1]])
        return self.decoder(pred), latent

# MPNN wrapper with dimension adjustment
class MPNNWrapper(nn.Module):
    """Wrapper for MPNN to ensure compatibility with MING architecture"""
    def __init__(self, hidden_size, depth):
        super().__init__()
        # Use the original MPNN implementation
        self.mpnn = MPNN(hidden_size, depth)
        # Adapter layer to ensure dimension compatibility
        self.adapter = nn.Linear(hidden_size, hidden_size)

    def forward(self, feature):
        # Pass through original MPNN and adapt dimensions
        return self.adapter(self.mpnn(feature))

class MPNN(nn.Sequential):

    def __init__(self, mpnn_hidden_size, mpnn_depth):
        super(MPNN, self).__init__()
        self.mpnn_hidden_size = mpnn_hidden_size
        self.mpnn_depth = mpnn_depth
        from DeepPurpose.chemutils import ATOM_FDIM, BOND_FDIM

        self.W_i = nn.Linear(ATOM_FDIM + BOND_FDIM, self.mpnn_hidden_size, bias=False)
        self.W_h = nn.Linear(self.mpnn_hidden_size, self.mpnn_hidden_size, bias=False)
        self.W_o = nn.Linear(ATOM_FDIM + self.mpnn_hidden_size, self.mpnn_hidden_size)



    ## utils.smiles2mpnnfeature -> utils.mpnn_collate_func -> utils.mpnn_feature_collate_func -> encoders.MPNN.forward
    def forward(self, feature):
        '''
            fatoms: (x, 39)
            fbonds: (y, 50)
            agraph: (x, 6)
            bgraph: (y, 6)
            drug_features = (fatoms, fbonds, agraph, bgraph, natoms_bond)
            graph_data = (adj_matrix, protein_features, idx_pairs)
        '''
        fatoms, fbonds, agraph, bgraph, N_atoms_bond = feature
        N_atoms_scope = []
        ##### tensor feature -> matrix feature
        N_a, N_b = 0, 0
        fatoms_lst, fbonds_lst, agraph_lst, bgraph_lst = [],[],[],[]
        for i in range(N_atoms_bond.shape[0]):
            atom_num = int(N_atoms_bond[i][0].item())
            bond_num = int(N_atoms_bond[i][1].item())

            fatoms_lst.append(fatoms[i,:atom_num,:])
            fbonds_lst.append(fbonds[i,:bond_num,:])
            agraph_lst.append(agraph[i,:atom_num,:] + N_a)
            bgraph_lst.append(bgraph[i,:bond_num,:] + N_b)

            N_atoms_scope.append((N_a, atom_num))
            N_a += atom_num
            N_b += bond_num


        fatoms = torch.cat(fatoms_lst, 0)
        fbonds = torch.cat(fbonds_lst, 0)
        agraph = torch.cat(agraph_lst, 0)
        bgraph = torch.cat(bgraph_lst, 0)
        ##### tensor feature -> matrix feature


        agraph = agraph.long()
        bgraph = bgraph.long()

        fatoms = create_var(fatoms).to(device)
        fbonds = create_var(fbonds).to(device)
        agraph = create_var(agraph).to(device)
        bgraph = create_var(bgraph).to(device)

        binput = self.W_i(fbonds) #### (y, d1)
        message = F.relu(binput)  #### (y, d1)

        for i in range(self.mpnn_depth - 1):
            nei_message = index_select_ND(message, 0, bgraph)
            nei_message = nei_message.sum(dim=1)
            nei_message = self.W_h(nei_message)
            message = F.relu(binput + nei_message) ### (y,d1)

        nei_message = index_select_ND(message, 0, agraph)
        nei_message = nei_message.sum(dim=1)
        ainput = torch.cat([fatoms, nei_message], dim=1)
        atom_hiddens = F.relu(self.W_o(ainput))
        output = [torch.mean(atom_hiddens.narrow(0, sts,leng), 0) for sts,leng in N_atoms_scope]
        output = torch.stack(output, 0)
        return output
ming_model = MING(
    mpnn_hidden_size=128,
    mpnn_depth=3,
    feature_number=256,
    mixhop_layers=[64, 64],
    device=torch.device('cpu')
)

# Input format
