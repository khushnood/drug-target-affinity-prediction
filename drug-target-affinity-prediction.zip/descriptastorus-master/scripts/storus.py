#!/usr/bin/env python
"""storus
see Description below
"""
from descriptastorus.cli import storus
storus.main()


        
            
            
