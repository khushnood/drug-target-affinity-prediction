#!/usr/bin/env python
# coding: utf-8
import os
os.environ['CUDA_VISIBLE_DEVICES']="-1"
import time
import pandas as pd
import os
from datetime import datetime
import json

from utils.save_time_data import save_timing_data_minimal

import os
from DeepPurpose import utils, dataset
from DeepPurpose import DTI as models
import warnings

warnings.filterwarnings("ignore")
from itertools import product


def run_DTI_drug_target_encoding(drug_encoding='MPNN', target_encoding='CNN', use_pretrained=False):
    print(f'Run started for Drug Encoding: {drug_encoding}, target encoding: {target_encoding}')
    result_dir = f'./result/{drug_encoding}_{target_encoding}'
    trained_model_saved = f'./trained_modles/trained_model_{drug_encoding}_{target_encoding}'

    X_drugs, X_targets, y = dataset.load_process_DAVIS(path='./data', binary=False, convert_to_log=True, threshold=30)
    #X_drugs, X_targets, y = dataset.load_process_KIBA(path = './data', binary = False)
    print('Drug 1: ' + X_drugs[0])
    print('Target 1: ' + X_targets[0])
    print('Score 1: ' + str(y[0]))
    print(f'number of records: {len(y)}')


    train, val, test = utils.data_process(X_drugs, X_targets, y,
                                          drug_encoding, target_encoding,
                                          split_method='random', frac=[0.7, 0.1, 0.2],
                                          random_seed=1)
    train.head(1)


    config = utils.generate_config(drug_encoding=drug_encoding,
                                   target_encoding=target_encoding,
                                   cls_hidden_dims=[1024, 1024, 512],
                                   train_epoch=15, # train_epoch = 15
                                   LR=0.001,
                                   batch_size=128,
                                   hidden_dim_drug=128,
                                   mpnn_hidden_size=128,
                                   mpnn_depth=3,
                                   cnn_target_filters=[32, 64, 96],
                                   cnn_target_kernels=[4, 8, 12],
                                   result_folder=result_dir
                                   )

    model = models.model_initialize(**config)

    if use_pretrained and os.path.exists(trained_model_saved):
        model = models.model_pretrained(path_dir=trained_model_saved)
    else:
        model.train(train, val, test)
        model.save_model(trained_model_saved)

    

    X_drug = ['CC1=C2C=C(C=CC2=NN1)C3=CC(=CN=C3)OCC(CC4=CC=CC=C4)N']
    X_target = [
        'MKKFFDSRREQGGSGLGSGSSGGGGSTSGLGSGYIGRVFGIGRQQVTVDEVLAEGGFAIVFLVRTSNGMKCALKRMFVNNEHDLQVCKREIQIMRDLSGHKNIVGYIDSSINNVSSGDVWEVLILMDFCRGGQVVNLMNQRLQTGFTENEVLQIFCDTCEAVARLHQCKTPIIHRDLKVENILLHDRGHYVLCDFGSATNKFQNPQTEGVNAVEDEIKKYTTLSYRAPEMVNLYSGKIITTKADIWALGCLLYKLCYFTLPFGESQVAICDGNFTIPDNSRYSQDMHCLIRYMLEPDPDKRPDIYQVSYFSFKLLKKECPIPNVQNSPIPAKLPEPVKASEAAAKKTQPKARLTDPIPTTETSIAPRQRPKAGQTQPNPGILPIQPALTPRKRATVQPPPQAAGSSNQPGLLASVPQPKPQAPPSQPLPQTQAKQPQAPPTPQQTPSTQAQGLPAQAQATPQHQQQLFLKQQQQQQQPPPAQQQPAGTFYQQQQAQTQQFQAVHPATQKPAIAQFPVVSQGGSQQQLMQNFYQQQQQQQQQQQQQQLATALHQQQLMTQQAALQQKPTMAAGQQPQPQPAAAPQPAPAQEPAIQAPVRQQPKVQTTPPPAVQGQKVGSLTPPSSPKTQRAGHRRILSDVTHSAVFGVPASKSTQLLQAAAAEASLNKSKSATTTPSGSPRTSQQNVYNPSEGSTWNPFDDDNFSKLTAEELLNKDFAKLGEGKHPEKLGGSAESLIPGFQSTQGDAFATTSFSAGTAEKRKGGQTVDSGLPLLSVSDPFIPLQVPDAPEKLIEGLKSPDTSLLLPDLLPMTDPFGSTSDAVIEKADVAVESLIPGLEPPVPQRLPSQTESVTSNRTDSLTGEDSLLDCSLLSNPTTDLLEEFAPTAISAPVHKAAEDSNLISGFDVPEGSDKVAEDEFDPIPVLITKNPQGGHSRNSSGSSESSLPNLARSLLLVDQLIDL']
    y = [7.365]
    X_pred = utils.data_process(X_drug, X_target, y,
                                drug_encoding, target_encoding,
                                split_method='no_split')
    y_pred = model.predict(X_pred)
    print('The predicted score is ' + str(y_pred))



def run_all_experiments_minimal(allPossibleWorkingCombinations, numperOfExperiments=1,pretrained = False):
    """
    Minimal integration - just wraps your existing function calls
    """
    all_timing_data = []

    for drug_encoding, target_encoding in sorted(allPossibleWorkingCombinations):

        print(f'Run started for Drug Encoding: {drug_encoding}, target encoding: {target_encoding}')

        iteration_times = []

        for i in range(numperOfExperiments):
            # Time each iteration
            start_time = time.time()

            # Your existing function call

            
            
            run_DTI_drug_target_encoding(
                drug_encoding=drug_encoding,
                target_encoding=target_encoding,
                use_pretrained=pretrained
            )


            end_time = time.time()
            iteration_time = end_time - start_time
            iteration_times.append(iteration_time)

            print(f"  Experiment {i+1}/{numperOfExperiments} completed in {iteration_time:.2f} seconds")

        # Calculate statistics
        if iteration_times:
            total_time = sum(iteration_times)
            avg_time = sum(iteration_times) / len(iteration_times)
            min_time = min(iteration_times)
            max_time = max(iteration_times)

            # Save to list
            timing_row = {
                'drug_encoding': drug_encoding,
                'target_encoding': target_encoding,
                'total_time_seconds': total_time,
                'avg_time_seconds': avg_time,
                'min_time_seconds': min_time,
                'max_time_seconds': max_time,
                'num_experiments': len(iteration_times),
                'iteration_times': iteration_times
            }
            all_timing_data.append(timing_row)
        #

            print(f"  Summary: Avg={avg_time:.2f}s, Total={total_time:.2f}s, Min={min_time:.2f}s, Max={max_time:.2f}s")
            save_timing_data_minimal(all_timing_data)



    return all_timing_data
if __name__ == '__main__':


    numperOfExperiments = 5

    allPossibleWorkingCombinations = {('DGL_GCN_SAGE_JK', 'ESPF')}
    all_timing_data = run_all_experiments_minimal(allPossibleWorkingCombinations, numperOfExperiments)




