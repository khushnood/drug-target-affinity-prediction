
import time
import pandas as pd
import os
from datetime import datetime
import json


def save_timing_data_minimal(all_timing_data):
    for timing_row in all_timing_data:
        drug_encoding = timing_row['drug_encoding']
        target_encoding = timing_row['target_encoding']
        os.makedirs(f'result/{drug_encoding}_{target_encoding}/', exist_ok=True)

        filename = f'result/{drug_encoding}_{target_encoding}/time_taken.csv'


        data = []
        for i, iter_time in enumerate(timing_row['iteration_times']):
            data.append({
                'iteration': i + 1,
                'time_seconds': iter_time,
                'drug_encoding': drug_encoding,
                'target_encoding': target_encoding
            })

        data.append({
            'iteration': 'AVERAGE',
            'time_seconds': timing_row['avg_time_seconds'],
            'drug_encoding': drug_encoding,
            'target_encoding': target_encoding,
            'note': f"Based on {timing_row['num_experiments']} experiments"
        })

        data.append({
            'iteration': 'TOTAL',
            'time_seconds': timing_row['total_time_seconds'],
            'drug_encoding': drug_encoding,
            'target_encoding': target_encoding
        })

        df = pd.DataFrame(data)
        df.to_csv(filename, index=False)

        print(f"Timing data saved to {filename}")


    create_combined_summary(all_timing_data)

def create_combined_summary(all_timing_data):

    summary_data = []

    for timing_row in all_timing_data:
        summary_data.append({
            'drug_encoding': timing_row['drug_encoding'],
            'target_encoding': timing_row['target_encoding'],
            'avg_time_seconds': timing_row['avg_time_seconds'],
            'total_time_seconds': timing_row['total_time_seconds'],
            'min_time_seconds': timing_row['min_time_seconds'],
            'max_time_seconds': timing_row['max_time_seconds'],
            'num_experiments': timing_row['num_experiments']
        })

    if summary_data:
        df_summary = pd.DataFrame(summary_data)
        df_summary = df_summary.sort_values('avg_time_seconds')

        summary_path = 'result/time_complexity/ALL_EXPERIMENTS_SUMMARY.csv'
        os.makedirs(f'result/time_complexity/', exist_ok=True)
        df_summary.to_csv(summary_path, index=False)

        print(f"\nCombined summary saved to: {summary_path}")
        print("\nPerformance Ranking (fastest to slowest):")
        print(df_summary[['drug_encoding', 'target_encoding', 'avg_time_seconds']].to_string(index=False))
